from scrapy import cmdline
cmdline.execute("scrapy crawl nvsydi -o items.csv".split())
